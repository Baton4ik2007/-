package com.example.salarytracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SalaryTrackerApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalaryTrackerApp() {
    var rate by remember { mutableStateOf("100") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var hoursInput by remember { mutableStateOf("") }
    var hoursByDate by remember { mutableStateOf(mutableMapOf<String, Int>()) }

    fun totalHours(): Int = hoursByDate.values.sum()

    fun bonusFor(total: Int): Int = when {
        total < 50 -> 0
        total < 80 -> 30
        total < 120 -> 80
        else -> 150
    }

    val total = totalHours()
    val bonus = bonusFor(total)
    val wage = rate.toIntOrNull() ?: 0
    val totalSalary = total * (wage + bonus)

    Scaffold(
        topBar = { TopAppBar(title = { Text("Учет заработка") }) }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = rate,
                onValueChange = { rate = it },
                label = { Text("Ставка (₽/ч)") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = date,
                onValueChange = { date = it },
                label = { Text("Дата (YYYY-MM-DD)") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = hoursInput,
                onValueChange = { hoursInput = it },
                label = { Text("Часы за дату") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    val h = hoursInput.toIntOrNull() ?: 0
                    if (h > 0) {
                        val key = try {
                            LocalDate.parse(date).format(DateTimeFormatter.ISO_DATE)
                        } catch (e: Exception) { LocalDate.now().toString() }
                        val curr = hoursByDate[key] ?: 0
                        hoursByDate[key] = curr + h
                        hoursInput = ""
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Добавить часы") }

            Spacer(Modifier.height(16.dp))
            Text("Часы по дням:", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            hoursByDate.toSortedMap().forEach { (d, h) ->
                Text("$d: $h ч.")
            }
            Spacer(Modifier.height(16.dp))
            Text("Общие часы: $total ч.")
            Text("Доплата: $bonus ₽")
            Text("Зарплата: $totalSalary ₽", style = MaterialTheme.typography.titleMedium)
        }
    }
}
